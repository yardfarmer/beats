package work;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config {

	private static Properties prop = new Properties();
	
	
	public static String getScriptName() {
		String scriptfile = getConfig("cfg_monitor_script");
		File file = new File(scriptfile);
		return file.canExecute() ? scriptfile : "";
	}
	
	public static int getMonitorInterval() {
		return Integer.parseInt(getConfig("cfg_monitor_interval"));
	}
	
	
	public static int getDBSyncInterval() {
		String dbInterval = getConfig("cfg_dbsync_interval");
		System.out.println(dbInterval);
		return ( dbInterval != null ) ? Integer.parseInt(dbInterval) : -1;
	}
	
	// 读取数据库是否采取数据同步模式
	public static boolean dbSyncMode() {
		String syncmode = getConfig("cfg_dbsync_mode");
		if( syncmode != null ) {
			if( syncmode.equalsIgnoreCase("true")) {
				return true;
			}
		}
		return false;
	}
	
	
	public static String getDBUrl() {
		String url = getConfig("cfg_dbsync_url");
		
		return ( url != null ) ? url : "";
	}
	
	
	public static String getDBUserName() {
		String dbname = getConfig("cfg_dbsync_username");
		
		return ( dbname != null ) ? dbname : "";
	}
	
	
	public static String getDBPasswd() {
		String dbpasswd = getConfig("cfg_dbsync_password");
		return ( dbpasswd != null ) ? dbpasswd : "";
	}
	
	public static String getDBLinkName() {
		String link = getConfig("cfg_dbsync_linkname");
		return ( link != null ) ? link : "";
	}
	
	
	private static String getConfig(String propName) {
		
		String scriptName = "/usr/local/beats/config.properties";

		File file = new File(scriptName);

		if (!file.exists()) {
			System.err
					.println("No found this config file : /usr/local/beats/config.properties ");
			return "";
		}
		
		if (!file.canRead()) {
			System.err.println("This config file is unreadable ");
			return "";
		}

		InputStream is = null;

		try {
			is = new FileInputStream(new File(scriptName));
			prop.load(is);

			return prop.getProperty(propName);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return "";
	}
}
