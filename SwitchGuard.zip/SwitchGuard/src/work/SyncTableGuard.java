package work;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SyncTableGuard extends Thread {

	DBUtil dbuUtil = new DBUtil();

	@Override
	public void run() {
		while (true) {
			
			// 读取数据同步模式,会根据主备变化而变化
			if (Config.dbSyncMode()) {

				try {

					System.out.println(new Date().toLocaleString() + "....>");
					dbuUtil.copyToStandby();

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			System.out.println("now is standyb");
			try {
				Thread.sleep(Config.getDBSyncInterval());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private class DBUtil {

		public DBUtil() {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}

		public Connection getConnection() {
			Connection conn = null;
			try {
				conn = DriverManager.getConnection(Config.getDBUrl(),
						Config.getDBUserName(), Config.getDBPasswd());
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return conn;
		}

		List<String> needSysntTabls = new ArrayList<String>();

		public void copyToStandby() {

			Connection conn = getConnection();
			Statement pstmt = null;

			ResultSet rst = null;
			try {

				pstmt = conn.createStatement();

				rst = pstmt
						.executeQuery("SELECT SYNCSTATE,TABLENAME FROM SYNC_TABLES");

				String needSyncTable;
				// 用之前把容器先清空
				needSysntTabls.clear();

				while (rst.next()) {
					int syncState = rst.getInt("SYNCSTATE");

					// 0 没有新状态
					if (syncState != 0) {
						needSyncTable = rst.getString("TABLENAME");
						needSysntTabls.add(needSyncTable);
					}
				}

				if (needSysntTabls.isEmpty()) {
					return;
				}

				int flag1, flag2, flag3;
				String standbyTable;

				for (String syncTableName : needSysntTabls) {
					flag1 = flag2 = flag3 = 0;
					standbyTable = syncTableName + "@" + Config.getDBLinkName();

					// 1.删除备库数据
					boolean del = pstmt.execute("DELETE FROM " + standbyTable);
					if (del) {
						flag1 = 1;
					}
					// 2.导进主库新数据
					boolean ins = pstmt.execute("INSERT INTO " + standbyTable
							+ " ( SELECT * FROM  " + syncTableName + ")");
					if (ins) {
						flag2 = 1;
					}
					// 3.重置记录表同步状态
					String updateSql = "UPDATE SYNC_TABLES  SET syncstate = 0 WHERE tablename = '"
							+ syncTableName + "'";
					System.out.println(updateSql);
					boolean up = pstmt.execute(updateSql);

					if (up) {
						flag3 = 1;
					}
					// 保证三步操作一致性
					// if( flag1 + flag2 + flag3 == 3 ) {
					// pstmt.execute("commit;");
					// }else {
					// pstmt.execute("rollback;");
					// }
				}

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (rst != null) {
					try {
						rst.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}

				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

		}

	}
}
