package work;

import java.io.IOException;

public class GuardThread {

	public static void main(String[] args) {

		Runtime rt = Runtime.getRuntime();
		String scriptname;
		
		// 如果配置了数据同步模式
		//if ( Config.dbSyncMode() ) {
			
			new SyncTableGuard().start();
		//}
		
		
		while (true) {
			scriptname = Config.getScriptName();
			try {
				if (scriptname == null || scriptname.isEmpty()) {
					return;
				}
				Process p = rt.exec(scriptname);

				if (p.waitFor() != 0) {
					System.out.println("This script execute Failed ");
				} else {
					System.out.println("Monitor work Success !");
				}

			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			try {
				Thread.sleep(Config.getMonitorInterval());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
